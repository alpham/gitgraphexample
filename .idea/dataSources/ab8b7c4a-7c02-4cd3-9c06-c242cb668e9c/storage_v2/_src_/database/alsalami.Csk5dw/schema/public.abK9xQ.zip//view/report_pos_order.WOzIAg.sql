create view report_pos_order as
  SELECT min(l.id) AS id,
    count(*) AS nbr_lines,
    s.date_order AS date,
    l.qty AS product_qty,
    l.sales_person_id,
    sum((l.qty * l.price_unit)) AS price_sub_total,
    sum(((l.qty * l.price_unit) * (l.discount / (100)::numeric))) AS total_discount,
    (sum((l.qty * l.price_unit)) / sum((l.qty * u.factor))) AS average_price,
    sum(sq.qty) AS qty_available,
    sum((to_char((date_trunc('day'::text, s.date_order) - date_trunc('day'::text, s.create_date)), 'DD'::text))::integer) AS delay_validation,
    (((l.qty * l.price_unit) * ((100)::numeric - l.discount)) / (100)::numeric) AS price_total,
    ((((((l.qty * l.price_unit) * ((100)::numeric - l.discount)) / (100)::numeric) * act.amount) / (100)::numeric) + (((l.qty * l.price_unit) * ((100)::numeric - l.discount)) / (100)::numeric)) AS price_subtotal_with_tax,
    s.id AS order_id,
    act.id AS tax_id,
    s.partner_id,
    s.state,
    s.user_id,
    s.location_id,
    s.company_id,
    s.sale_journal AS journal_id,
    l.product_id,
    pt.categ_id AS product_categ_id,
    p.product_tmpl_id,
    ps.config_id,
    pt.pos_categ_id,
    pc.stock_location_id,
    s.pricelist_id,
    s.session_id,
    (s.invoice_id IS NOT NULL) AS invoiced
   FROM ((((((((((pos_order_line l
     LEFT JOIN pos_order s ON ((s.id = l.order_id)))
     LEFT JOIN product_product p ON ((l.product_id = p.id)))
     LEFT JOIN product_template pt ON ((p.product_tmpl_id = pt.id)))
     LEFT JOIN product_uom u ON ((u.id = pt.uom_id)))
     LEFT JOIN pos_session ps ON ((s.session_id = ps.id)))
     LEFT JOIN pos_config pc ON ((ps.config_id = pc.id)))
     LEFT JOIN stock_quant sq ON ((sq.product_id = p.id)))
     JOIN stock_location sl ON (((sq.location_id = sl.id) AND ((sl.usage)::text = 'internal'::text))))
     JOIN account_tax_pos_order_line_rel atl ON ((atl.pos_order_line_id = sl.id)))
     JOIN account_tax act ON ((act.id = atl.account_tax_id)))
  GROUP BY s.id, s.date_order, s.partner_id, s.state, pt.categ_id, s.user_id, s.location_id, s.company_id, s.sale_journal, s.pricelist_id, s.invoice_id, s.create_date, s.session_id, l.product_id, l.qty, l.price_unit, act.amount, act.id, l.sales_person_id, l.discount, pt.pos_categ_id, p.product_tmpl_id, ps.config_id, pc.stock_location_id
 HAVING (sum((l.qty * u.factor)) <> (0)::numeric);

