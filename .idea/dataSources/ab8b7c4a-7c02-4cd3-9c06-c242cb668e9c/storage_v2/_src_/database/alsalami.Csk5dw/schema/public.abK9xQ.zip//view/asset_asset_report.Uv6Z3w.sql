create view asset_asset_report as
  SELECT min(dl.id) AS id,
    dl.name,
    dl.depreciation_date,
    a.date,
        CASE
            WHEN (dlmin.id = min(dl.id)) THEN a.value
            ELSE (0)::numeric
        END AS gross_value,
    dl.amount AS depreciation_value,
    dl.amount AS installment_value,
        CASE
            WHEN dl.move_check THEN dl.amount
            ELSE (0)::numeric
        END AS posted_value,
        CASE
            WHEN (NOT dl.move_check) THEN dl.amount
            ELSE (0)::numeric
        END AS unposted_value,
    dl.asset_id,
    dl.move_check,
    a.category_id AS asset_category_id,
    a.partner_id,
    a.state,
    count(dl.*) AS installment_nbr,
    count(dl.*) AS depreciation_nbr,
    a.company_id
   FROM ((account_asset_depreciation_line dl
     LEFT JOIN account_asset_asset a ON ((dl.asset_id = a.id)))
     LEFT JOIN ( SELECT min(d.id) AS id,
            ac.id AS ac_id
           FROM (account_asset_depreciation_line d
             JOIN account_asset_asset ac ON ((ac.id = d.asset_id)))
          GROUP BY ac.id) dlmin ON ((dlmin.ac_id = a.id)))
  GROUP BY dl.amount, dl.asset_id, dl.depreciation_date, dl.name, a.date, dl.move_check, a.state, a.category_id, a.partner_id, a.company_id, a.value, a.id, a.salvage_value, dlmin.id;

