create view report_stock_forecast as
  SELECT min(final.id) AS id,
    final.product_id,
    final.date,
    sum(final.product_qty) AS quantity,
    sum(sum(final.product_qty)) OVER (PARTITION BY final.product_id ORDER BY final.date) AS cumulative_quantity
   FROM ( SELECT min(main.id) AS id,
            main.product_id,
            sub.date,
                CASE
                    WHEN (main.date = sub.date) THEN sum(main.product_qty)
                    ELSE (0)::double precision
                END AS product_qty
           FROM (( SELECT min(sq.id) AS id,
                    sq.product_id,
                    date_trunc('week'::text, (to_date(to_char((('now'::text)::date)::timestamp with time zone, 'YYYY/MM/DD'::text), 'YYYY/MM/DD'::text))::timestamp with time zone) AS date,
                    sum(sq.qty) AS product_qty
                   FROM ((stock_quant sq
                     LEFT JOIN product_product ON ((product_product.id = sq.product_id)))
                     LEFT JOIN stock_location location_id ON ((sq.location_id = location_id.id)))
                  WHERE ((location_id.usage)::text = 'internal'::text)
                  GROUP BY (date_trunc('week'::text, (to_date(to_char((('now'::text)::date)::timestamp with time zone, 'YYYY/MM/DD'::text), 'YYYY/MM/DD'::text))::timestamp with time zone)), sq.product_id
                UNION ALL
                 SELECT min((- sm.id)) AS id,
                    sm.product_id,
                        CASE
                            WHEN (sm.date_expected > ('now'::text)::date) THEN date_trunc('week'::text, (to_date(to_char(sm.date_expected, 'YYYY/MM/DD'::text), 'YYYY/MM/DD'::text))::timestamp with time zone)
                            ELSE date_trunc('week'::text, (to_date(to_char((('now'::text)::date)::timestamp with time zone, 'YYYY/MM/DD'::text), 'YYYY/MM/DD'::text))::timestamp with time zone)
                        END AS date,
                    sum(sm.product_qty) AS product_qty
                   FROM (((stock_move sm
                     LEFT JOIN product_product ON ((product_product.id = sm.product_id)))
                     LEFT JOIN stock_location dest_location ON ((sm.location_dest_id = dest_location.id)))
                     LEFT JOIN stock_location source_location ON ((sm.location_id = source_location.id)))
                  WHERE (((sm.state)::text = ANY (ARRAY[('confirmed'::character varying)::text, ('assigned'::character varying)::text, ('waiting'::character varying)::text])) AND ((source_location.usage)::text <> 'internal'::text) AND ((dest_location.usage)::text = 'internal'::text))
                  GROUP BY sm.date_expected, sm.product_id
                UNION ALL
                 SELECT min((- sm.id)) AS id,
                    sm.product_id,
                        CASE
                            WHEN (sm.date_expected > ('now'::text)::date) THEN date_trunc('week'::text, (to_date(to_char(sm.date_expected, 'YYYY/MM/DD'::text), 'YYYY/MM/DD'::text))::timestamp with time zone)
                            ELSE date_trunc('week'::text, (to_date(to_char((('now'::text)::date)::timestamp with time zone, 'YYYY/MM/DD'::text), 'YYYY/MM/DD'::text))::timestamp with time zone)
                        END AS date,
                    sum((- sm.product_qty)) AS product_qty
                   FROM (((stock_move sm
                     LEFT JOIN product_product ON ((product_product.id = sm.product_id)))
                     LEFT JOIN stock_location source_location ON ((sm.location_id = source_location.id)))
                     LEFT JOIN stock_location dest_location ON ((sm.location_dest_id = dest_location.id)))
                  WHERE (((sm.state)::text = ANY (ARRAY[('confirmed'::character varying)::text, ('assigned'::character varying)::text, ('waiting'::character varying)::text])) AND ((source_location.usage)::text = 'internal'::text) AND ((dest_location.usage)::text <> 'internal'::text))
                  GROUP BY sm.date_expected, sm.product_id) main
             LEFT JOIN ( SELECT DISTINCT date_search.date
                   FROM ( SELECT date_trunc('week'::text, (('now'::text)::date)::timestamp with time zone) AS date
                        UNION ALL
                         SELECT date_trunc('week'::text, (to_date(to_char(sm.date_expected, 'YYYY/MM/DD'::text), 'YYYY/MM/DD'::text))::timestamp with time zone) AS date
                           FROM ((stock_move sm
                             LEFT JOIN stock_location source_location ON ((sm.location_id = source_location.id)))
                             LEFT JOIN stock_location dest_location ON ((sm.location_dest_id = dest_location.id)))
                          WHERE (((sm.state)::text = ANY (ARRAY[('confirmed'::character varying)::text, ('assigned'::character varying)::text, ('waiting'::character varying)::text])) AND (sm.date_expected > ('now'::text)::date) AND ((((dest_location.usage)::text = 'internal'::text) AND ((source_location.usage)::text <> 'internal'::text)) OR (((source_location.usage)::text = 'internal'::text) AND ((dest_location.usage)::text <> 'internal'::text))))) date_search) sub ON ((sub.date IS NOT NULL)))
          GROUP BY main.product_id, sub.date, main.date) final
  GROUP BY final.product_id, final.date;

